using System;
using System.Collections.Generic;

public static class PesoLettere
{

    public static int Pesa(string input)
    {
        int idx=0;
        int cntnum=0;

        for(idx=0; idx<input.Length; idx++)
        {
            switch (input[idx])
            {
                case 'a':
                    cntnum++;
                break;

                case 'A':
                    cntnum++;
                break;

                case 'e':
                    cntnum++;
                break;

                case 'E':
                    cntnum++;
                break;

                case 'i':
                    cntnum++;
                break;

                case 'I':
                    cntnum++;
                break;

                case 'o':
                    cntnum++;
                break;

                case 'O':
                    cntnum++;
                break;

                case 'u':
                    cntnum++;
                break;

                case 'U':
                    cntnum++;
                break;

                case 'l':
                    cntnum++;
                break;

                case 'L':
                    cntnum++;
                break;

                case 'n':
                    cntnum++;
                break;

                case 'N':
                    cntnum++;
                break;

                case 'r':
                    cntnum++;
                break;

                case 'R':
                    cntnum++;
                break;

                case 's':
                    cntnum++;
                break;

                case 'S':
                    cntnum++;
                break;

                case 't':
                    cntnum++;
                break;

                case 'T':
                    cntnum++;
                break;
                
                //2 punti

                case 'd':
                    cntnum=cntnum+2;
                break;

                case 'D':
                    cntnum=cntnum+2;
                break;

                case 'g':
                    cntnum=cntnum+2;
                break;

                case 'G':
                    cntnum=cntnum+2;
                break;

                //3 punti

                case 'b':
                    cntnum=cntnum+3;
                break;

                case 'B':
                    cntnum=cntnum+3;
                break;

                case 'c':
                    cntnum=cntnum+3;
                break;

                case 'C':
                    cntnum=cntnum+3;
                break;

                case 'm':
                    cntnum=cntnum+3;
                break;

                case 'M':
                    cntnum=cntnum+3;
                break;

                case 'p':
                    cntnum=cntnum+3;
                break;

                case 'P':
                    cntnum=cntnum+3;
                break;

                //4 punti

                case 'f':
                    cntnum=cntnum+4;
                break;

                case 'F':
                    cntnum=cntnum+4;
                break;

                case 'h':
                    cntnum=cntnum+4;
                break;

                case 'H':
                    cntnum=cntnum+4;
                break;

                case 'v':
                    cntnum=cntnum+4;
                break;

                case 'V':
                    cntnum=cntnum+4;
                break;

                case 'w':
                    cntnum=cntnum+4;
                break;

                case 'W':
                    cntnum=cntnum+4;
                break;

                case 'y':
                    cntnum=cntnum+4;
                break;

                case 'Y':
                    cntnum=cntnum+4;
                break;

                //5 punti

                case 'k':
                    cntnum=cntnum+5;
                break;

                case 'K':
                    cntnum=cntnum+5;
                break;

                //8 punti

                case 'j':
                    cntnum=cntnum+8;
                break;

                case 'J':
                    cntnum=cntnum+8;
                break;

                case 'x':
                    cntnum=cntnum+8;
                break;

                case 'X':
                    cntnum=cntnum+8;
                break;

                //10 punti

                case 'q':
                    cntnum=cntnum+10;
                break;

                case 'Q':
                    cntnum=cntnum+10;
                break;

                case 'z':
                    cntnum=cntnum+10;
                break;

                case 'Z':
                    cntnum=cntnum+10;
                break;
            }
            
        }

        return cntnum;
    }
}